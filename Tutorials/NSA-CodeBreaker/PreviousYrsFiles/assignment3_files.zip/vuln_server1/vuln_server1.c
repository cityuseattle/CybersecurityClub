#include <stdio.h>
#include <stdlib.h>
#include <winsock.h>

#define IP_ADDRESS  ""
#define PORT_NUMBER 31337
#define BUF_SIZE    2048

void process(SOCKET);

void main(int argc, char *argv[]) {
	SOCKET sock;
	SOCKET new_sock;
	struct sockaddr_in sa;
	WSADATA wsaData;

	if (WSAStartup(MAKEWORD(2, 0), &wsaData) != 0) {
		fprintf(stderr,"WSAStartup() failed");
		exit(1);
	}

	printf("Initializing the server...\n");
	memset(&sa, 0, sizeof(struct sockaddr_in));

	sa.sin_family = AF_INET;
    // bind to a specific address
	//sa.sin_addr.s_addr = inet_addr(IP_ADDRESS);
    // bind to all addresses
	sa.sin_addr.s_addr = htonl(INADDR_ANY);
	sa.sin_port = htons(PORT_NUMBER);
	sock = socket(AF_INET, SOCK_STREAM, 0);

	if (sock < 0) {
		printf("Could not create socket server...\n");
		exit(1);
	}
		
	if (bind(sock, (struct sockaddr *)&sa, sizeof(struct sockaddr_in)) == SOCKET_ERROR) {
		closesocket(sock);
		printf("Could not bind socket...\n");
		exit(1);
	}

	printf("Listening for connections...\n");
	listen(sock, 10);
	while (1) {
		new_sock = accept(sock, NULL, NULL);
    	printf("Client connected\n");

		if (new_sock < 0) {
			printf("Error waiting for new connection!\n");
			exit(1);
		}
		
		process(new_sock);
		closesocket(new_sock);
	}
}

void process(SOCKET sock) {
    char* tmp;
	char buf[1024]; // whoops! should've used the defined BUF_SIZE here
    int i;
    
	memset(&buf, 0, sizeof(buf));
	tmp = malloc(BUF_SIZE);

    i = recv(sock, tmp, BUF_SIZE-1, 0);
    tmp[i+1] = '\x00';
    
    // this would be alright if buf and tmp were the same size
    strcpy(&buf, tmp);

    free(tmp);
	// print data
	printf("Got message:\n%s\n", buf);
}